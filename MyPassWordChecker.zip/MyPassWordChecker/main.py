import requests
import hashlib
import sys


# READ ME PLEASE!
# HOW TO WORK
# OPEN TERMINAL
# WRITE python main.py
# THEN WRITE ANY PASSWORD YOU DESIRE
# FOR MULTIPLE PASSWORDS PRESS SPACE AFTER EACH PASSWORD

def request_api_data(query_char):
    """ function only accepts strings """

    url = 'https://api.pwnedpasswords.com/range/' + query_char
    response = requests.get(url)
    if response.status_code != 200:
        # 200 means connected, 400 means didn't connect
        raise RuntimeError(f"Error fetching: {response.status_code}, check the api and try again! ")
    return response


def get_passwords_leaks_count(hashes, hashes_to_check):
    hashes = (line.split(":") for line in hashes.text.splitlines())
    for h, count in hashes:
        if h == hashes_to_check:
            return count
    return 0
    # checks how many times our password has been leaked


def pwned_api_check(password):
    sha1password = hashlib.sha1(password.encode("utf-8")).hexdigest().upper()
    first_5_letters, rest_letters = sha1password[:5:], sha1password[5::]
    response = request_api_data(first_5_letters)
    print(response)
    return get_passwords_leaks_count(response, rest_letters)


def main_function(args):
    for password in args:
        count = pwned_api_check(password)
        if count:
            print(f'the {password} was found {count} times! assign a new password!')
        else:
            print(f" your {password} was not found,you are good to go!")

    return "done!"


if __name__ == "__main__":
    sys.exit(main_function(sys.argv[1:]))
